const { User } = require("../models");
module.exports = function (req, res, next) {
    try {
        const user = User.findOne({
            where: {
                id: req.params,
            },
        });
        const authorization = req.user.id;
        if (authorization != user.id) {
            throw new Error("UNAUTHORIZED")
        }

        next();
    }
    
    catch(err) {
        res.status(401).json({
            status: "FAIL",
            message: "UNAUTHORIZED"
        })
    }
}