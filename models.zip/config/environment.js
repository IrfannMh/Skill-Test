const {
    JWT_SIGNATURE_KEY = 'Rahasia'
} = process.env;

module.exports = {
    JWT_SIGNATURE_KEY
}
