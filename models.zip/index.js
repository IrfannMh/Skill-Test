const express = require('express');
const app = express();
const router = require('./router');
const {PORT = 8000} = process.env;

app.use(express.json())
app.use(express.urlencoded({extended:true}))
app.use(router);
app.listen(PORT, () => console.log(`Listening on port http://localhost:${PORT}`))